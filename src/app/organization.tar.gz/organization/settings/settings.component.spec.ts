/* tslint:disable:no-unused-variable */

/*import { By }           from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { addProviders, async, inject } from '@angular/core/testing';
import { SettingsComponent } from './settings.component';

describe('Component: Settings', () => {
  it('should create an instance', () => {
    let component = new SettingsComponent();
    expect(component).toBeTruthy();
  });
});
*/