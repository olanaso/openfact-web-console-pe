export * from './general-information.component';
