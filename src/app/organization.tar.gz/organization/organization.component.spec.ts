/* tslint:disable:no-unused-variable */

/*import { By }           from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { addProviders, async, inject } from '@angular/core/testing';
import { OrganizationComponent } from './organization.component';

describe('Component: Organization', () => {
  it('should create an instance', () => {
    let component = new OrganizationComponent();
    expect(component).toBeTruthy();
  });
});*/
