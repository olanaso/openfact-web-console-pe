/* tslint:disable:no-unused-variable */

/*import { By }           from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { addProviders, async, inject } from '@angular/core/testing';
import { TasksScheduleComponent } from './tasks-schedule.component';

describe('Component: TasksSchedule', () => {
  it('should create an instance', () => {
    let component = new TasksScheduleComponent();
    expect(component).toBeTruthy();
  });
});*/
