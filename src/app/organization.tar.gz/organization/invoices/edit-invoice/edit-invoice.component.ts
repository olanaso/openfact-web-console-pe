import { Component, OnInit } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'app-edit-invoice',
  templateUrl: 'edit-invoice.component.html',
  styleUrls: ['edit-invoice.component.css']
})
export class EditInvoiceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
