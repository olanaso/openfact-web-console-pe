/* tslint:disable:no-unused-variable */

/*import { By }           from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { addProviders, async, inject } from '@angular/core/testing';
import { InvoicesComponent } from './invoices.component';

describe('Component: Invoices', () => {
  it('should create an instance', () => {
    let component = new InvoicesComponent();
    expect(component).toBeTruthy();
  });
});*/
