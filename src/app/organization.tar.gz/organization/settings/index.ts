export * from './address';
export * from './general-information';
export * from './certificate';
export * from './tasks-schedule';
export * from './settings.component';