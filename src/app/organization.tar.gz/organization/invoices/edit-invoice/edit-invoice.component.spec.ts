/* tslint:disable:no-unused-variable */

import { By }           from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { addProviders, async, inject } from '@angular/core/testing';
import { EditInvoiceComponent } from './edit-invoice.component';

describe('Component: EditInvoice', () => {
  it('should create an instance', () => {
    let component = new EditInvoiceComponent();
    expect(component).toBeTruthy();
  });
});
